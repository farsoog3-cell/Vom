import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.160.0/examples/jsm/loaders/GLTFLoader.js';

// --- تهيئة مسرح اللعبة المحرك ثلاثي الأبعاد ---
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x22301a);
scene.fog = new THREE.FogExp2(0x22301a, 0.0025);

const camera = new THREE.PerspectiveCamera(38, window.innerWidth/window.innerHeight, 0.1, 1000);
camera.position.set(0, 65, 55); camera.lookAt(0, 0, 5);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

const modelLoader = new GLTFLoader();

// --- 🎵 إعدادات مدير الأصوات والموسيقى (Audio System) ---
const listener = new THREE.AudioListener();
camera.add(listener);

const audioLoader = new THREE.AudioLoader();
const bgMusic = new THREE.Audio(listener);
const sfxPlayer = new THREE.Audio(listener);

// مسارات الملفات الصوتية
const audioTracks = {
    normal: './assets/audio/music/main_theme.mp3',
    hype: './assets/audio/music/battle_hype.mp3',
    click: './assets/audio/sfx/click.mp3',
    unitReady: './assets/audio/sfx/unit_ready.mp3',
    construct: './assets/audio/sfx/construct.mp3'
};

let currentTrackMode = 'normal';

function loadAndPlayMusic(path) {
    if (bgMusic.isPlaying) bgMusic.stop();
    audioLoader.load(path, (buffer) => {
        bgMusic.setBuffer(buffer);
        bgMusic.setLoop(true);
        bgMusic.setVolume(document.getElementById('volume-music').value / 100);
        bgMusic.play();
    }, undefined, (err) => console.log("ملاحظة: ضع ملفات الموسيقى لتفعيل الصوت التلقائي"));
}

function playSFX(path) {
    audioLoader.load(path, (buffer) => {
        if (sfxPlayer.isPlaying) sfxPlayer.stop();
        sfxPlayer.setBuffer(buffer);
        sfxPlayer.setVolume(document.getElementById('volume-sfx').value / 100);
        sfxPlayer.play();
    }, undefined, (err) => console.log("ملاحظة: ملف الصوت المؤثر مفقود"));
}

// بدء التشغيل التلقائي للموسيقى الافتراضية
loadAndPlayMusic(audioTracks.normal);

// ربط عناصر قائمة الإعدادات الصوتية والتحكم
document.getElementById('volume-music').oninput = (e) => bgMusic.setVolume(e.target.value / 100);
document.getElementById('volume-sfx').oninput = (e) => sfxPlayer.setVolume(e.target.value / 100);

document.getElementById('track-normal').onclick = () => {
    if(currentTrackMode === 'normal') return;
    currentTrackMode = 'normal';
    document.getElementById('track-normal').classList.add('active');
    document.getElementById('track-hype').classList.remove('active');
    loadAndPlayMusic(audioTracks.normal);
};
document.getElementById('track-hype').onclick = () => {
    if(currentTrackMode === 'hype') return;
    currentTrackMode = 'hype';
    document.getElementById('track-hype').classList.add('active');
    document.getElementById('track-normal').classList.remove('active');
    loadAndPlayMusic(audioTracks.hype);
};

// --- تحكم جودة الرسوميات وسرعة المحرك ---
let gameSpeedModifier = 1.0;
let graphicQualityHigh = true;

document.getElementById('game-speed').oninput = (e) => { gameSpeedModifier = e.target.value / 100; };
document.getElementById('fx-low').onclick = () => {
    graphicQualityHigh = false;
    document.getElementById('fx-low').classList.add('active');
    document.getElementById('fx-high').classList.remove('active');
    renderer.shadowMap.enabled = false; scene.fog = null;
};
document.getElementById('fx-high').onclick = () => {
    graphicQualityHigh = true;
    document.getElementById('fx-high').classList.add('active');
    document.getElementById('fx-low').classList.remove('active');
    renderer.shadowMap.enabled = true; scene.fog = new THREE.FogExp2(0x22301a, 0.0025);
};

const fsBtn = document.getElementById('fullscreen-btn');
fsBtn.onclick = () => {
    playSFX(audioTracks.click);
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().then(() => { fsBtn.innerText = "❌"; });
    } else {
        document.exitFullscreen().then(() => { fsBtn.innerText = "📺"; });
    }
};

const settingsBtn = document.getElementById('settings-btn');
const settingsMenu = document.getElementById('settings-menu');
const closeSettingsBtn = document.getElementById('btn-close-settings');

settingsBtn.onclick = () => { playSFX(audioTracks.click); settingsMenu.style.display = 'flex'; };
closeSettingsBtn.onclick = () => { playSFX(audioTracks.click); settingsMenu.style.display = 'none'; msg("⚙️ تم حفظ تعديلات الغرفة التكتيكية."); };

// --- الإضاءة والأرضية الأساسية ---
const ambient = new THREE.AmbientLight(0xffffff, 0.7); scene.add(ambient);
const sunLight = new THREE.DirectionalLight(0xfffaed, 1.3);
sunLight.position.set(80, 140, 60); sunLight.castShadow = true; scene.add(sunLight);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(1200, 1200), new THREE.MeshStandardMaterial({ color: 0x3a4a2b, roughness: 0.85 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

const grid = new THREE.GridHelper(500, 120, 0x162410, 0x1d3015);
grid.position.y = 0.02; scene.add(grid);

const moveMarker = new THREE.Mesh(new THREE.RingGeometry(0.1, 1.3, 4), new THREE.MeshBasicMaterial({ color: 0x00ff33, side: THREE.DoubleSide, transparent: true, opacity: 0.9 }));
moveMarker.rotation.x = -Math.PI / 2; moveMarker.position.y = 0.05; moveMarker.visible = false; scene.add(moveMarker);

const mCanvas = document.getElementById('minimap-canvas'); const mCtx = mCanvas.getContext('2d');

// --- إعدادات اللعب الأساسية والمصفوفات ---
let money = 3000; let selectedObject = null; let buildMode = null; let tacticalActionMode = null; let radarPart = null;
const dozers = []; const structures = []; const units = []; const smokeParticles = []; const floatingTexts = [];
const raycaster = new THREE.Raycaster(); const mouse = new THREE.Vector2();

const buildGhost = new THREE.Mesh(new THREE.BoxGeometry(10, 0.2, 10), new THREE.MeshBasicMaterial({ color: 0x00ff33, transparent: true, opacity: 0.4 }));
buildGhost.visible = false; scene.add(buildGhost);

function msg(text) {
    const container = document.getElementById('notification-container');
    if (!container) return;
    const toast = document.createElement('div'); toast.className = 'toast-msg'; toast.innerText = text;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 30);
    setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 250); }, 2500);
}

// --- دالة استدعاء الموديلات المخصصة أو الافتراضية البديلة في حال عدم توفر الملف ---
function loadCustomModel(path, fallbackGeometry, fallbackMaterial, onLoaded) {
    modelLoader.load(path, (gltf) => {
        const mesh = gltf.scene;
        mesh.traverse(child => { if(child.isMesh) { child.castShadow = true; child.receiveShadow = true; } });
        onLoaded(mesh);
    }, undefined, (err) => {
        // آلية الطوارئ البديلة (Fallback) عند غياب الموديل الأصلي لضمان استمرار اللعب بدون كراش
        const mesh = new THREE.Mesh(fallbackGeometry, fallbackMaterial);
        onLoaded(mesh);
    });
}

// --- توليد العناصر والوحدات ---
function createDozerUnit(x, z) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    
    const geom = new THREE.BoxGeometry(2.6, 1.5, 3.6);
    const mat = new THREE.MeshStandardMaterial({ color: 0xcc7a00 });
    
    loadCustomModel('./assets/models/dozer.glb', geom, mat, (loadedMesh) => {
        group.add(loadedMesh);
    });
    
    group.userData = { type: 'dozer', targetX: x, targetZ: z, isBuilding: false, currentProject: null, radius: 2.2 };
    scene.add(group); dozers.push(group);
}

function createHQStructure(x, z) {
    const bGroup = new THREE.Group();
    bGroup.position.set(x, 0, z);
    
    const geom = new THREE.BoxGeometry(12, 5.5, 12);
    const mat = new THREE.MeshStandardMaterial({ color: 0x4d5656 });
    
    loadCustomModel('./assets/models/hq.glb', geom, mat, (loadedMesh) => {
        bGroup.add(loadedMesh);
    });
    
    radarPart = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.5, 0.2), new THREE.MeshStandardMaterial({ color: 0xcc3300 }));
    radarPart.position.set(4, 9, 4); bGroup.add(radarPart);
    
    bGroup.userData = { type: 'hq', progress: 100, radius: 7.0 };
    scene.add(bGroup); structures.push(bGroup);
}

// بدء الخريطة بإنشاء المقر الرئيسي والجرافة الأولى
createHQStructure(0, 0);
createDozerUnit(-15, 15);

function spawnFloatingText(text, position, customColor = '#00ff33') {
    const canvas = document.createElement('canvas'); canvas.width = 128; canvas.height = 64;
    const g = canvas.getContext('2d'); g.fillStyle = customColor; g.font = 'bold 28px Courier New'; g.textAlign = 'center'; g.fillText(text, 64, 40);
    const tex = new THREE.CanvasTexture(canvas); const mat = new THREE.SpriteMaterial({ map: tex, transparent: true });
    const sprite = new THREE.Sprite(mat); sprite.position.copy(position); sprite.position.y += 4; sprite.scale.set(6, 3, 1);
    scene.add(sprite); floatingTexts.push({ sprite: sprite, age: 0 });
}

function createSmokeParticle(pos, heightOffset = 4, customColor = 0x556655) {
    if(!graphicQualityHigh) return;
    const pMat = new THREE.MeshBasicMaterial({ color: customColor, transparent: true, opacity: 0.4 });
    const pMesh = new THREE.Mesh(new THREE.SphereGeometry(Math.random() * 0.4 + 0.2, 8, 8), pMat);
    pMesh.position.set(pos.x + (Math.random()-0.5)*2, pos.y + heightOffset, pos.z + (Math.random()-0.5)*2);
    scene.add(pMesh);
    smokeParticles.push({ mesh: pMesh, vx: (Math.random() - 0.5) * 0.03, vy: Math.random() * 0.04 + 0.05, vz: (Math.random() - 0.5) * 0.03, life: 1.0 });
}

// --- نظام الإدخال واللمس والاشتباك المعزز بالصوت ---
let isDragging = false, prevX, prevY;
window.addEventListener('touchstart', (e) => {
    if(e.touches[0].clientY > window.innerHeight - 140 || (settingsMenu && settingsMenu.style.display === 'flex')) return;
    isDragging = true; prevX = e.touches[0].clientX; prevY = e.touches[0].clientY;
    mouse.x = (e.touches[0].clientX / window.innerWidth) * 2 - 1; mouse.y = -(e.touches[0].clientY / window.innerHeight) * 2 + 1;
    handleInteraction();
});

window.addEventListener('touchmove', (e) => {
    if (!isDragging) return;
    if (!buildMode && !selectedObject) {
        camera.position.x -= (e.touches[0].clientX - prevX) * 0.14; camera.position.z -= (e.touches[0].clientY - prevY) * 0.14;
    } else if (buildMode) {
        mouse.x = (e.touches[0].clientX / window.innerWidth) * 2 - 1; mouse.y = -(e.touches[0].clientY / window.innerHeight) * 2 + 1;
        raycaster.setFromCamera(mouse, camera); const intersects = raycaster.intersectObject(ground);
        if(intersects.length > 0) buildGhost.position.set(Math.round(intersects[0].point.x/2)*2, 0.1, Math.round(intersects[0].point.z/2)*2);
    }
    prevX = e.touches[0].clientX; prevY = e.touches[0].clientY;
});
window.addEventListener('touchend', () => { isDragging = false; });

function checkCollisions(unitObj) {
    structures.forEach(struct => {
        if(struct.userData.progress >= 100 && !struct.userData.isDemolishing) {
            const dx = unitObj.position.x - struct.position.x; const dz = unitObj.position.z - struct.position.z;
            const dist = Math.sqrt(dx*dx + dz*dz); const minDist = unitObj.userData.radius + struct.userData.radius;
            if(dist < minDist) {
                const overlap = minDist - dist; unitObj.position.x += (dx / dist) * overlap; unitObj.position.z += (dz / dist) * overlap;
                unitObj.userData.targetX = unitObj.position.x; unitObj.userData.targetZ = unitObj.position.z;
            }
        }
    });
}

function showWaypoint(x, z, color = 0x00ff33) {
    moveMarker.position.set(x, 0.06, z); moveMarker.scale.set(1, 1, 1);
    moveMarker.material.color.setHex(color); moveMarker.material.opacity = 0.9; moveMarker.visible = true;
}

function handleInteraction() {
    raycaster.setFromCamera(mouse, camera);
    const allObjects = [...dozers, ...structures, ...units];

    if (tacticalActionMode && selectedObject) {
        const intersects = raycaster.intersectObjects(allObjects, true);
        const groundIntersects = raycaster.intersectObject(ground);
        if (tacticalActionMode === 'attack' && intersects.length > 0) {
            let clickedTarget = intersects[0].object;
            while(clickedTarget.parent && clickedTarget.parent !== scene) clickedTarget = clickedTarget.parent;
            selectedObject.userData.targetX = clickedTarget.position.x; selectedObject.userData.targetZ = clickedTarget.position.z;
            showWaypoint(clickedTarget.position.x, clickedTarget.position.z, 0xff3300);
            msg(`⚔️ تم توجيه أمر الاشتباك المباشر للمجموعة!`);
            playSFX(audioTracks.click);
        } else if (tacticalActionMode === 'defend' && groundIntersects.length > 0) {
            const pt = groundIntersects[0].point; selectedObject.userData.targetX = pt.x; selectedObject.userData.targetZ = pt.z;
            showWaypoint(pt.x, pt.z, 0x00ffbb); msg(`🛡️ تثبيت حراسة المنطقة المستهدفة.`);
            playSFX(audioTracks.click);
        }
        tacticalActionMode = null;
        document.getElementById('btn-attack-mode').classList.remove('active');
        document.getElementById('btn-defend-mode').classList.remove('active');
        return;
    }

    if (buildMode && selectedObject && selectedObject.userData.type === 'dozer') {
        const intersects = raycaster.intersectObject(ground);
        if (intersects.length > 0) {
            const loc = intersects[0].point; const tx = Math.round(loc.x/2)*2; const tz = Math.round(loc.z/2)*2;
            selectedObject.userData.targetX = tx; selectedObject.userData.targetZ = tz;
            selectedObject.userData.isBuilding = true; selectedObject.userData.buildingType = buildMode;
            showWaypoint(tx, tz); msg("🚜 الجرافة تتوجه للبدء في صب الخرسانة..."); 
            playSFX(audioTracks.construct);
            cancelSelection();
        }
        return;
    }

    if (selectedObject && ['tank', 'infantry', 'dozer'].includes(selectedObject.userData.type)) {
        const intersects = raycaster.intersectObject(ground);
        if (intersects.length > 0 && !buildMode) {
            const loc = intersects[0].point; selectedObject.userData.targetX = loc.x; selectedObject.userData.targetZ = loc.z;
            showWaypoint(loc.x, loc.z); msg("الوحدات في طريقها للإحداثيات المحددة.");
            playSFX(audioTracks.click);
            if(selectedObject.userData.type !== 'dozer') cancelSelection();
            return;
        }
    }

    const intersects = raycaster.intersectObjects(allObjects, true);
    if (intersects.length > 0) {
        let rootObj = intersects[0].object;
        while(rootObj.parent && rootObj.parent !== scene) rootObj = rootObj.parent;
        if(rootObj.userData.isDemolishing) { cancelSelection(); return; }

        selectedObject = rootObj; updateProfileUI(selectedObject.userData.type);
        playSFX(audioTracks.click);
        
        document.getElementById('btn-spawn-dozer').disabled = (selectedObject.userData.type !== 'hq');
        document.getElementById('btn-factory').disabled = (selectedObject.userData.type !== 'dozer' || selectedObject.userData.currentProject != null);
        document.getElementById('btn-oil').disabled = (selectedObject.userData.type !== 'dozer' || selectedObject.userData.currentProject != null);
        
        const isCombat = ['tank', 'infantry'].includes(selectedObject.userData.type);
        document.getElementById('btn-attack-mode').disabled = !isCombat;
        document.getElementById('btn-defend-mode').disabled = !isCombat;
        document.getElementById('btn-stop-order').disabled = !['dozer', 'tank', 'infantry'].includes(selectedObject.userData.type);
        
        const isReadyFactory = (selectedObject.userData.type === 'factory' && selectedObject.userData.progress >= 100);
        document.getElementById('btn-infantry').disabled = !isReadyFactory;
        document.getElementById('btn-tank').disabled = !isReadyFactory;

        const canSell = ['factory', 'oil'].includes(selectedObject.userData.type) && selectedObject.userData.progress >= 100;
        document.getElementById('btn-sell-building').disabled = !canSell;
        return;
    }
    cancelSelection();
}

function updateProfileUI(type) {
    const iconEl = document.getElementById('profile-icon'); const nameEl = document.getElementById('profile-name');
    if(!iconEl || !nameEl) return;
    switch(type) {
        case 'hq': iconEl.innerText = "🏢"; nameEl.innerText = "مركز القيادة الكلي"; break;
        case 'dozer': iconEl.innerText = "🚜"; nameEl.innerText = "جرافة التشييد ومسح الأراضي"; break;
        case 'factory': iconEl.innerText = "🏭"; nameEl.innerText = "المصنع الحربي للآليات"; break;
        case 'oil': iconEl.innerText = "🛢️"; nameEl.innerText = "بئر بترول الإمداد المالي"; break;
        case 'tank': iconEl.innerText = "💥"; nameEl.innerText = "دبابة المعركة الهجومية"; break;
        case 'infantry': iconEl.innerText = "🪖"; nameEl.innerText = "فرقة الكوماندوز المشاة"; break;
        default: iconEl.innerText = "📡"; nameEl.innerText = "نظام الرادار جاهز";
    }
}

document.getElementById('btn-attack-mode').onclick = () => { tacticalActionMode = 'attack'; msg("⚔️ انقر لتحديد الهدف المعادي."); document.getElementById('btn-attack-mode').classList.add('active'); };
document.getElementById('btn-defend-mode').onclick = () => { tacticalActionMode = 'defend'; msg("🛡️ حدد موقع تمركز الحراسة."); document.getElementById('btn-defend-mode').classList.add('active'); };

document.getElementById('btn-sell-building').onclick = () => {
    if (!selectedObject) return;
    const type = selectedObject.userData.type;
    let refund = type === 'factory' ? 300 : 400; money += refund; updateUI();
    spawnFloatingText(`+$${refund}`, selectedObject.position, '#cc7a00');
    selectedObject.userData.isDemolishing = true; cancelSelection();
    playSFX(audioTracks.click);
};

document.getElementById('btn-stop-order').onclick = () => {
    if (!selectedObject) return;
    selectedObject.userData.targetX = selectedObject.position.x; selectedObject.userData.targetZ = selectedObject.position.z;
    if (selectedObject.userData.type === 'dozer' && selectedObject.userData.currentProject) {
        scene.remove(selectedObject.userData.currentProject); structures.splice(structures.indexOf(selectedObject.userData.currentProject), 1);
        selectedObject.userData.currentProject = null; money += 300; updateUI();
    }
    moveMarker.visible = false; cancelSelection();
    playSFX(audioTracks.click);
};

function triggerProductionTimer(btnId, duration, onComplete, factoryObj) {
    const btn = document.getElementById(btnId); const progressEl = btn.querySelector('.build-progress');
    btn.disabled = true; let elapsed = 0;
    if(factoryObj) { factoryObj.userData.isProducing = true; factoryObj.userData.doorTargetY = -1.8; }

    const interval = setInterval(() => {
        elapsed += 0.1 * gameSpeedModifier; let pct = (elapsed / duration) * 100; if(progressEl) progressEl.style.width = `${pct}%`;
        if (elapsed >= duration) {
            clearInterval(interval); if(progressEl) progressEl.style.width = '0%'; btn.disabled = false;
            if(factoryObj) { factoryObj.userData.isProducing = false; factoryObj.userData.doorTargetY = 0.8; }
            onComplete();
        }
    }, 100);
}

document.getElementById('btn-spawn-dozer').onclick = () => {
    if (money < 1000) return; money -= 1000; updateUI();
    playSFX(audioTracks.click);
    triggerProductionTimer('btn-spawn-dozer', 4.0, () => {
        createDozerUnit((Math.random() * 12) - 6, 15);
        msg("🚜 تم تدشين جرافة صيانة وبناء عسكرية جديدة.");
        playSFX(audioTracks.unitReady);
    }, null);
};

document.getElementById('btn-infantry').onclick = () => {
    if (money < 100 || !selectedObject) return; money -= 100; updateUI();
    const fact = selectedObject; playSFX(audioTracks.click);
    triggerProductionTimer('btn-infantry', 3.0, () => {
        if(fact.userData.isDemolishing) return;
        
        const uGroup = new THREE.Group();
        uGroup.position.set(fact.position.x, 0.9, fact.position.z + 5.5);
        
        const geom = new THREE.CylinderGeometry(0.4, 0.4, 1.8);
        const mat = new THREE.MeshStandardMaterial({ color: 0x11aa22 });
        
        loadCustomModel('./assets/models/infantry.glb', geom, mat, (loadedMesh) => {
            uGroup.add(loadedMesh);
        });
        
        uGroup.userData = { type: 'infantry', targetX: uGroup.position.x, targetZ: uGroup.position.z + 4, radius: 1.0 };
        scene.add(uGroup); units.push(uGroup); 
        msg("🪖 تم إخراج مشاة قتالية من المصنع.");
        playSFX(audioTracks.unitReady);
    }, fact);
};

document.getElementById('btn-tank').onclick = () => {
    if (money < 450 || !selectedObject) return; money -= 450; updateUI();
    const fact = selectedObject; playSFX(audioTracks.click);
    triggerProductionTimer('btn-tank', 6.0, () => {
        if(fact.userData.isDemolishing) return;
        
        const tGroup = new THREE.Group();
        tGroup.position.set(fact.position.x, 0, fact.position.z + 5.5);
        
        const baseGeom = new THREE.BoxGeometry(2.4, 0.9, 3.6);
        const baseMat = new THREE.MeshStandardMaterial({ color: 0x1f4024 });
        
        loadCustomModel('./assets/models/tank.glb', baseGeom, baseMat, (loadedMesh) => {
            tGroup.add(loadedMesh);
        });
        
        tGroup.userData = { type: 'tank', targetX: tGroup.position.x, targetZ: tGroup.position.z + 4, radius: 2.0 };
        scene.add(tGroup); units.push(tGroup); 
        msg("💥 الدبابة الهجومية جاهزة لتلقي الأوامر.");
        playSFX(audioTracks.unitReady);
    }, fact);
};

function startBuildMode(type) {
    let cost = type === 'factory' ? 600 : 800; if (money < cost) { msg("عفواً، الموارد غير كافية!"); return; }
    playSFX(audioTracks.click); buildMode = type; buildGhost.visible = true;
}
document.getElementById('btn-factory').onclick = () => startBuildMode('factory');
document.getElementById('btn-oil').onclick = () => startBuildMode('oil');

function startConstructionUnderground(type, x, z) {
    money -= (type === 'factory' ? 600 : 800); updateUI();
    const bGroup = new THREE.Group();
    bGroup.position.set(x, -7, z);

    if (type === 'factory') {
        const geom = new THREE.BoxGeometry(11, 4.5, 8.5); const mat = new THREE.MeshStandardMaterial({ color: 0x5e6b58 });
        loadCustomModel('./assets/models/factory.glb', geom, mat, (loadedMesh) => { bGroup.add(loadedMesh); });
        
        const door = new THREE.Mesh(new THREE.BoxGeometry(3.5, 2.4, 0.2), new THREE.MeshStandardMaterial({ color: 0x111610 })); door.position.set(0, 0.8, 4.3); bGroup.add(door);
        bGroup.userData = { type: type, progress: 0, radius: 6.5, isProducing: false, doorTargetY: 0.8, doorMesh: door, isDemolishing: false };
    } else {
        const geom = new THREE.CylinderGeometry(2.5, 3.5, 7, 16); const mat = new THREE.MeshStandardMaterial({ color: 0x1f2620 });
        loadCustomModel('./assets/models/oil.glb', geom, mat, (loadedMesh) => { bGroup.add(loadedMesh); });
        
        const pumpRig = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.5, 5), new THREE.MeshStandardMaterial({ color: 0x475449 })); pumpRig.position.set(0, 7, 0); bGroup.add(pumpRig);
        bGroup.userData = { type: type, progress: 0, radius: 4.5, lastIncomeTime: 0, isDemolishing: false };
    }
    
    scene.add(bGroup); structures.push(bGroup); return bGroup;
}

function cancelSelection() {
    selectedObject = null; buildMode = null; tacticalActionMode = null; buildGhost.visible = false; updateProfileUI('none');
    document.getElementById('btn-spawn-dozer').disabled = true; document.getElementById('btn-factory').disabled = true;
    document.getElementById('btn-oil').disabled = true; document.getElementById('btn-stop-order').disabled = true;
    document.getElementById('btn-attack-mode').disabled = true; document.getElementById('btn-defend-mode').disabled = true;
    document.getElementById('btn-infantry').disabled = true; document.getElementById('btn-tank').disabled = true;
    document.getElementById('btn-sell-building').disabled = true;
}

function updateUI() { document.getElementById('money-txt').innerText = money; }

function drawMinimap() {
    if(!mCtx) return;
    mCtx.clearRect(0, 0, 110, 110); const mapScale = 0.5; const cx = 55, cy = 55;
    mCtx.fillStyle = '#ffffff'; mCtx.fillRect(cx + camera.position.x * mapScale - 1, cy + camera.position.z * mapScale - 1, 3, 3);
    structures.forEach(s => { 
        if(s.userData.isDemolishing) return;
        mCtx.fillStyle = s.userData.type === 'hq' ? '#00ff33' : (s.userData.type === 'factory' ? '#ffaa00' : '#00aaff'); mCtx.fillRect(cx + s.position.x * mapScale - 2, cy + s.position.z * mapScale - 2, 5, 5); 
    });
    dozers.forEach(d => { mCtx.fillStyle = '#ffff00'; mCtx.fillRect(cx + d.position.x * mapScale - 1.5, cy + d.position.z * mapScale - 1.5, 3, 3); });
    units.forEach(u => { mCtx.fillStyle = u.userData.type === 'tank' ? '#ff3333' : '#00ff33'; mCtx.beginPath(); mCtx.arc(cx + u.position.x * mapScale, cy + u.position.z * mapScale, 1.5, 0, Math.PI*2); mCtx.fill(); });
}

// --- ميكانيكا وحركة المحرك والأنيميشن ---
const clock = new THREE.Clock();
function animate() {
    requestAnimationFrame(animate); const time = clock.getElapsedTime();
    const speedFactor = 0.16 * gameSpeedModifier; const unitSpeedFactor = 0.2 * gameSpeedModifier;

    if (radarPart) radarPart.rotation.y += 0.04 * gameSpeedModifier;
    if (moveMarker.visible) { moveMarker.scale.x += 0.02; moveMarker.scale.y += 0.02; moveMarker.material.opacity -= 0.03; if (moveMarker.material.opacity <= 0) moveMarker.visible = false; }

    dozers.forEach(dozer => {
        const dx = dozer.userData.targetX - dozer.position.x; const dz = dozer.userData.targetZ - dozer.position.z; const dist = Math.sqrt(dx*dx + dz*dz);
        if (dist > 0.6) { dozer.rotation.y = Math.atan2(dx, dz); dozer.position.x += (dx / dist) * speedFactor; dozer.position.z += (dz / dist) * speedFactor; }
        else if (dozer.userData.isBuilding) { dozer.userData.isBuilding = false; dozer.userData.currentProject = startConstructionUnderground(dozer.userData.buildingType, dozer.position.x, dozer.position.z); }
        checkCollisions(dozer);
        if (dozer.userData.currentProject) {
            const proj = dozer.userData.currentProject;
            if (proj.userData.progress < 100) { proj.userData.progress += 0.5 * gameSpeedModifier; proj.position.y = -7 + (proj.userData.progress / 100) * 7; } 
            else { proj.userData.progress = 100; dozer.userData.currentProject = null; msg(`🏭 تم الانتهاء من الأعمال الإنشائية في الموقع الهيكلي.`); }
        }
    });

    for (let i = structures.length - 1; i >= 0; i--) {
        const struct = structures[i];
        if (struct.userData.isDemolishing) {
            struct.position.y -= 0.08 * gameSpeedModifier;
            if (Math.random() < 0.5) createSmokeParticle(struct.position, 1, 0x1c211a);
            if (struct.position.y <= -7) { scene.remove(struct); structures.splice(i, 1); }
            continue;
        }
        if (struct.userData.type === 'oil' && struct.userData.progress >= 100) {
            if(struct.children[1]) struct.children[1].rotation.z = Math.sin(time * 4 * gameSpeedModifier) * 0.2;
            if (Math.random() < 0.1) createSmokeParticle(struct.position, 7.5);
            if (time - struct.userData.lastIncomeTime > 3.0 / gameSpeedModifier) {
                struct.userData.lastIncomeTime = time; money += 50; updateUI();
                spawnFloatingText("+$50", struct.position, '#00ff33');
            }
        }
        if (struct.userData.type === 'factory' && struct.userData.progress >= 100) {
            const door = struct.userData.doorMesh; 
            if(door) door.position.y += (struct.userData.doorTargetY - door.position.y) * 0.1 * gameSpeedModifier;
            if (struct.userData.isProducing && Math.random() < 0.25) {
                const chimneyPos = new THREE.Vector3(-3.5, 5, -2).add(struct.position); createSmokeParticle(chimneyPos, 1.5);
            }
        }
    }

    for (let i = smokeParticles.length - 1; i >= 0; i--) {
        const p = smokeParticles[i]; p.mesh.position.x += p.vx; p.mesh.position.y += p.vy; p.mesh.position.z += p.vz; p.life -= 0.015; p.mesh.material.opacity = p.life * 0.4;
        if (p.life <= 0) { scene.remove(p.mesh); smokeParticles.splice(i, 1); }
    }

    for (let i = floatingTexts.length - 1; i >= 0; i--) {
        const t = floatingTexts[i]; t.sprite.position.y += 0.06; t.age += 0.02;
        if (t.age > 1.0) { scene.remove(t.sprite); floatingTexts.splice(i, 1); }
    }

    units.forEach(unit => {
        const dx = unit.userData.targetX - unit.position.x; const dz = unit.userData.targetZ - unit.position.z; const dist = Math.sqrt(dx*dx + dz*dz);
        if (dist > 0.5) { unit.rotation.y = Math.atan2(dx, dz); unit.position.x += (dx / dist) * unitSpeedFactor; unit.position.z += (dz / dist) * unitSpeedFactor; }
        checkCollisions(unit);
    });

    drawMinimap(); renderer.render(scene, camera);
}
animate();

window.addEventListener('resize', () => { camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix(); renderer.setSize(window.innerWidth, window.innerHeight); });